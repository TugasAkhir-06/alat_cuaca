from flask import Flask, request, jsonify
from flask_cors import CORS
import csv, os
from datetime import datetime
import requests

app = Flask(__name__)
CORS(app)  # Allow access from frontend (e.g., Streamlit)

# Lokasi file CSV lokal
DATA_FILE = "alat_cuaca/data_historis.csv"

# SheetDB API endpoint
SHEETDB_API = "https://sheetdb.io/api/v1/es90elmaoophd"

# Kolom CSV
CSV_FIELDNAMES = [
    "timestamp", "source", "wspd_kmph", "arah", "rot_per_sec", "suhu",
    "kelembapan", "tekanan", "curah_hujan", "ph_tanah", "kelembapan_tanah"
]


def safe_float(val, min_val=None, max_val=None):
    try:
        f = float(val)
        if (min_val is not None and f < min_val) or (max_val is not None
                                                     and f > max_val):
            return ""
        return f
    except:
        return ""


def save_to_sheetdb(data):
    try:
        response = requests.post(SHEETDB_API,
                                 json={"data": [data]},
                                 headers={"Content-Type": "application/json"})
        if response.status_code != 201:
            print(
                f"[SheetDB] Gagal upload: {response.status_code}, {response.text}"
            )
    except Exception as e:
        print(f"[SheetDB ERROR] {e}")


def save_data(data):
    complete_data = {key: data.get(key, "") for key in CSV_FIELDNAMES}
    complete_data["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Konversi nilai ke angka aman
    for col in [
            "wspd_kmph", "rot_per_sec", "suhu", "kelembapan", "tekanan",
            "curah_hujan"
    ]:
        complete_data[col] = safe_float(complete_data[col])
    complete_data["ph_tanah"] = safe_float(complete_data["ph_tanah"], 0, 14)
    complete_data["kelembapan_tanah"] = safe_float(
        complete_data["kelembapan_tanah"], 0, 100)

    # Simpan ke CSV lokal
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    file_exists = os.path.isfile(DATA_FILE)
    with open(DATA_FILE, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDNAMES)
        if not file_exists:
            writer.writeheader()
        writer.writerow(complete_data)

    # Simpan ke SheetDB
    save_to_sheetdb(complete_data)


@app.route("/")
def index():
    return jsonify({"message": "✅ Server Flask aktif dan siap terima data!"})


@app.route("/upload_cuaca", methods=["POST"])
def upload_cuaca():
    data = request.json
    data["source"] = "cuaca"
    save_data(data)
    return jsonify({"status": "success", "message": "✅ Data cuaca diterima!"})


@app.route("/upload_tanah", methods=["POST"])
def upload_tanah():
    data = request.json
    data["source"] = "tanah"
    save_data(data)
    return jsonify({"status": "success", "message": "✅ Data tanah diterima!"})


@app.route("/data", methods=["GET"])
def get_data():
    try:
        response = requests.get(SHEETDB_API)
        if response.status_code != 200:
            return jsonify({"error": "Gagal ambil data dari SheetDB"}), 500
        return jsonify(response.json())
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/data-terbaru", methods=["GET"])
def get_latest_data():
    try:
        response = requests.get(SHEETDB_API)
        data = response.json()
        if not data:
            return jsonify({"error": "Data kosong"}), 404

        latest = sorted(data, key=lambda x: x["timestamp"], reverse=True)[0]
        return jsonify(latest)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
